//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DczgaSw9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-l4LBrlU9.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-l4LBrlU9.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-QCWwEX62.js"]
	}
} });
//#endregion
export { tsrStartManifest };
